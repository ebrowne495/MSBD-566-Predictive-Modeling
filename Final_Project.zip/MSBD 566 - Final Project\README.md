# Accessibility to Early Detection of Type-2 Diabetes — Code Package

MSBD 566: Predictive Modeling and Analytics · Final Project
Evan Browne, Francena Scott, David Reyes · November 17, 2026

This repository reproduces every table and figure in the manuscript. It compares
logistic regression and XGBoost on the 2015 BRFSS Diabetes Health Indicators
survey, asks whether self-reported health and lifestyle answers can classify
recorded prediabetes or diabetes with ROC-AUC above 0.75, and identifies the five
leading predictors with permutation importance.

**Reproducibility status:** verified end-to-end on 2026-11-17 with the pinned
environment below. All values in manuscript Tables 1–5, Figure 1, and the five
permutation-importance drops regenerate exactly.

---

## 1. Contents

| Path | What it is |
|---|---|
| `Predictive_Modeling_Project_Code.ipynb` | The complete pipeline (11 code cells, 7 stages) |
| `README.md` | This file: data access, setup, run order, output map, data dictionary |
| `requirements.txt` | Pinned Python packages |
| `diabetes_012_health_indicators_BRFSS2015.csv` | Input data (bundled at the repo root; see §3) |
| `outputs/` | Created at run time; every table and figure in the manuscript |

The dataset (22.7 MB) ships with this package, so a fresh unzip runs without
any download step. §3 also gives the download instructions and integrity checks
for anyone who needs to fetch it again.

---

## 2. What the code does

1. Loads the 253,680 × 22 BRFSS file and defines the outcome as
   `Diabetes_012 > 0` (prediabetes or diabetes = 1; neither = 0).
2. Runs data-quality checks: missing values, duplicate rows, outcome counts.
3. Splits rows 64 / 16 / 20 into train / validation / test, stratified on the
   outcome, seed 42.
4. Fits logistic regression (C = 0.1 and 1.0) and XGBoost (max_depth = 3 and 5)
   on the training rows only, choosing each model's setting by validation ROC-AUC.
5. Compares the two selected models on validation rows and draws Figure 1.
6. Scores the winner once on the sealed test rows and reports the five leading
   predictors from permutation importance.

---

## 3. Data access

**Source:** Teboul, A. *Diabetes Health Indicators Dataset.* Kaggle.
<https://www.kaggle.com/datasets/alexteboul/diabetes-health-indicators-dataset>

Derived from the CDC Behavioral Risk Factor Surveillance System (BRFSS) 2015.
Public, de-identified survey data; no ethics approval or data-use agreement
required for this project.

**File:** `diabetes_012_health_indicators_BRFSS2015.csv` (22.7 MB). It is bundled
at the repository root, so a fresh unzip runs with no download step. If it is
missing, obtain it in one of these two ways:

**A. Manual download.** Open the Kaggle page, download the file above, and place
it in the repository root (next to the notebook). No renaming.

**B. Direct download** (same author's public mirror, no Kaggle account):

```bash
curl -L -o diabetes_012_health_indicators_BRFSS2015.csv \
  https://raw.githubusercontent.com/AlexTeboul/datasets/main/diabetes_012_health_indicators_BRFSS2015.csv
```

```powershell
# PowerShell equivalent
Invoke-WebRequest -Uri "https://raw.githubusercontent.com/AlexTeboul/datasets/main/diabetes_012_health_indicators_BRFSS2015.csv" -OutFile "diabetes_012_health_indicators_BRFSS2015.csv"
```

**Verify the download before running.** These four checks must hold; they are
also asserted / printed by the notebook:

```python
import pandas as pd
df = pd.read_csv("diabetes_012_health_indicators_BRFSS2015.csv")
assert df.shape == (253680, 22)
assert df["Diabetes_012"].value_counts().sort_index().tolist() == [213703, 4631, 35346]
assert df.isna().sum().sum() == 0
assert df.duplicated().sum() == 23899
```

The notebook reads the CSV from the working directory, so start Jupyter in the
repository root.

---

## 4. Environment

Python 3.12.10 was used. Create a virtual environment and install the pins:

```bash
python -m venv .venv
# Windows:  .venv\Scripts\activate
# macOS/Linux:  source .venv/bin/activate
pip install -r requirements.txt
pip install jupyterlab        # only needed to run the notebook
```

`requirements.txt` pins the versions used to produce the manuscript:

| Package | Version |
|---|---|
| numpy | 2.5.4 |
| pandas | 3.1.1 |
| scipy | 1.18.1 |
| scikit-learn | 1.9.1 |
| xgboost | 3.4.1 |
| matplotlib | 3.11.2 |

No GPU, no network access, and no credentials are needed after the CSV is in
place. Runtime is roughly 1–3 minutes on a laptop CPU.

> **Version note:** XGBoost results can shift in the third decimal across major
> versions. The manuscript values were reproduced with xgboost 3.4.1; re-running
> with a different version may change ROC-AUC by a few ten-thousandths.

---

## 5. Run order

The pipeline is a single notebook, executed top to bottom. There are no manual
steps between stages and no hidden state.

1. Clone or unzip the repository and `cd` into it.
2. Confirm that `diabetes_012_health_indicators_BRFSS2015.csv` is in the root
   (it is bundled; if not, see §3).
3. Create the environment and install the pins (§4).
4. Launch Jupyter from the repository root: `jupyter lab`.
5. Open `Predictive_Modeling_Project_Code.ipynb`.
6. **Kernel → Restart Kernel and Run All Cells** (this also clears stored outputs).
7. Confirm that `outputs/` now contains the files listed in §6.

Stage order inside the notebook:

| Stage | Code cells | What happens |
|---|---|---|
| 0. Load | 1 | Read CSV, define binary outcome |
| 1. Data checks | 2–4 | Missing values, duplicates, summary CSVs |
| 2. Split | 5 | 64/16/20 stratified split, scaler fit on train only |
| 3. Models | 6–7 | Logistic regression and XGBoost tuning on validation |
| 4. Compare | 8–9 | Comparison table and Figure 1 |
| 5. Explain | 10 | Permutation importance, top five |
| 6. Final test | 11 | One-time scoring of the sealed test rows |

`RUN_FINAL_TEST = True` gates the last stage. The test rows are not touched
before it, which is how leakage is prevented at the design level.

---

## 6. Output → manuscript map

Every file is written to `outputs/` (created automatically by the first data
cell). Filenames match the `Source:` lines in the manuscript captions.

"Cell N" below counts **code cells only, in run order** (1–11); the notebook's
own `In [ ]` numbers are higher because markdown cells sit between them.

| Output file | Produced by | Manuscript object |
|---|---|---|
| `data_summary.csv` | Cell 2 | Table 1 |
| `outcome_counts.csv` | Cell 3 | Table 1 |
| `split_ids.csv` | Cell 5 | Table 2 (row-level split assignment) |
| `run_details.json` | Cell 5 | Table 2 (seed, split, row counts) |
| `logistic_regression_validation_results.csv` | Cell 6 | Table 3 |
| `xgboost_validation_results.csv` | Cell 7 | Supplementary (model selection) |
| `model_comparison.csv` | Cell 8 | Table 4 |
| `model_comparison_figure.png` | Cell 9 | Figure 1 |
| `top_five_factors.csv` | Cell 10 | "Five Leading Predictors" values |
| `final_test_results.csv` | Cell 11 | Table 5 |
| `feature_checks.csv` | Cell 4 | Supplementary data dictionary audit |

Reproduced values (for a quick sanity check):

| Object | Value |
|---|---|
| Logistic regression validation ROC-AUC | 0.8200 |
| XGBoost validation ROC-AUC | 0.8265 |
| XGBoost final test ROC-AUC | 0.8242 |
| Test recall / precision at 0.50 | 78.64% / 33.48% |
| Top five drops | GenHlth 0.0482, BMI 0.0391, Age 0.0350, HighBP 0.0144, HighChol 0.0128 |

---

## 7. Data dictionary

21 predictors; all numeric and complete (no missing cells). Codes follow the
BRFSS 2015 codebook as distributed in this file.

| Column | Type / coding | Meaning |
|---|---|---|
| `Diabetes_012` | 0 / 1 / 2 — **target** | 0 = no diabetes, 1 = prediabetes, 2 = diabetes |
| `HighBP` | 0 / 1 | Ever told had high blood pressure |
| `HighChol` | 0 / 1 | Ever told had high cholesterol |
| `CholCheck` | 0 / 1 | Cholesterol check within past 5 years |
| `BMI` | continuous | Body mass index |
| `Smoker` | 0 / 1 | Smoked at least 100 cigarettes in life |
| `Stroke` | 0 / 1 | Ever told had a stroke |
| `HeartDiseaseorAttack` | 0 / 1 | Coronary heart disease or myocardial infarction |
| `PhysActivity` | 0 / 1 | Physical activity in past 30 days, excluding job |
| `Fruits` | 0 / 1 | Consumes fruit one or more times per day |
| `Veggies` | 0 / 1 | Consumes vegetables one or more times per day |
| `HvyAlcoholConsump` | 0 / 1 | Heavy drinking (men >14, women >7 drinks/week) |
| `AnyHealthcare` | 0 / 1 | Any health care coverage |
| `NoDocbcCost` | 0 / 1 | Could not see a doctor in past 12 months due to cost |
| `GenHlth` | 1–5 | General health: 1 excellent … 5 poor |
| `MentHlth` | 0–30 | Days mental health not good in past 30 days |
| `PhysHlth` | 0–30 | Days physical health not good in past 30 days |
| `DiffWalk` | 0 / 1 | Serious difficulty walking or climbing stairs |
| `Sex` | 0 / 1 | 0 = female, 1 = male |
| `Age` | 1–13 | Age category: 1 = 18–24 … 13 = 80+ |
| `Education` | 1–6 | 1 = never attended school … 6 = college graduate |
| `Income` | 1–8 | 1 = <$10,000 … 8 = ≥$200,000 |

No identifier column is present. That is why rows are split individually rather
than grouped by respondent (see §9).

---

## 8. Design decisions and why

- **Binary outcome.** Categories 1 (prediabetes) and 2 (diabetes) are merged, so
  the task is "reported either condition vs neither." This raises the positive
  rate from 1.8% (prediabetes alone) to 15.76% and matches the survey question
  the manuscript asks.
- **Single stratified 64/16/20 split, seed 42.** Chosen over cross-validation so
  the test rows stay untouched until one final scoring. Stratification keeps the
  15.76% positive rate in every part.
- **Scaler fit on training rows only.** Logistic regression needs scaled inputs;
  fitting the scaler on the full file would leak validation/test information
  through the feature means and standard deviations.
- **Trees use unscaled predictors.** Splits are invariant to monotone rescaling,
  so scaling would add nothing for XGBoost.
- **Class weighting from training labels only.** `class_weight="balanced"` for
  logistic regression and `scale_pos_weight` for XGBoost are computed from
  `y_train`, never from validation or test labels.
- **Selection rule fixed in advance.** Each model's setting is chosen by
  validation ROC-AUC, and the model is chosen by the same metric. The 0.75 goal
  and the 0.50 cutoff were set before results were seen.
- **Permutation importance on validation rows**, 5 repeats, seed 42, scored by
  ROC-AUC drop. It measures how much the fitted model relies on each answer, not
  causality, and not importance in a hypothetical refit.

---

## 9. Reproducibility notes and known limitations

**What is guaranteed**

- Fixed seeds: `SEED = 42` is used for the split, both model families, and
  permutation importance.
- No hard-coded absolute paths. The only path is the CSV filename in the working
  directory, and `outputs/` is created with `mkdir(parents=True, exist_ok=True)`.
- No manual steps between cells; "Restart & Run All" reproduces everything.
- Row order is restored after splitting (`np.sort`), so outputs are stable.
- Split-disjointness and split-completeness are asserted in code.

**What is not done (honest scope)**

- No confidence intervals for ROC-AUC, no calibration analysis, and no subgroup
  error analysis by age or sex. The manuscript states this in the Results and
  Limitations sections.
- Only one data split, so the 0.0065 ROC-AUC gap between models is a point
  estimate without an interval.
- `permutation_importance` is evaluated on the model that wins the validation
  comparison. In this run that is XGBoost, which consumes unscaled rows. If a
  change to the hyperparameters made logistic regression win, the call would
  need the scaled validation matrix (`X_val_s`) instead of `X_val`.
- No respondent identifiers exist, so a grouped split is not possible; identical
  rows (23,899 beyond first occurrence) are kept, and the manuscript discusses
  the resulting uncertainty.
- Survey weights and BRFSS design variables are absent, so the reported
  percentages are not national prevalence estimates.

---

## 10. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `FileNotFoundError: diabetes_012_health_indicators_BRFSS2015.csv` | CSV not in the working directory; start Jupyter in the repo root or move the file |
| `ModuleNotFoundError: xgboost` | `pip install -r requirements.txt` in the active environment |
| `NameError: display` | Cells are written for Jupyter; run in JupyterLab/Notebook, not as a plain script |
| Slightly different ROC-AUC | Different xgboost version; see the note in §4 |
| `outputs/` empty | The notebook was not run to completion; "Restart & Run All" |

---

## 11. Authors and contributions

- **Evan Browne** — data splitting; model comparison; model training and final
  test (with Francena Scott).
- **Francena Scott** — training the logistic regression and XGBoost models;
  evaluating the selected model on the final test data.
- **David Reyes** — data-quality checks; permutation importance and the five
  leading predictors.
- All three authors contributed to the conclusion and references.

---

## 12. Availability and license

- **Code:** included in the Blackboard submission zip (the graded copy): notebook,
  `README.md`, `requirements.txt`, and the prepared dataset.
- **Data:** public BRFSS 2015, distributed via Kaggle (link in §3). No
  redistribution restrictions apply to the underlying CDC survey data; cite the
  Kaggle dataset and the CDC BRFSS.
- **Code license:** MIT (or the course's preferred license).
